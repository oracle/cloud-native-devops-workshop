/**
 * The ExpressJS namespace.
 * @external ExpressApplicationObject
 * @see {@link http://expressjs.com/3x/api.html#app}
 */

/**
 * Mobile Cloud custom code service entry point.
 * @param {external:ExpressApplicationObject}
 * service 
 */
module.exports = function(service) {

    var customers = require('./lib/customers.json');
    var items = require('./lib/inventoryItems.json');
    var PCSTTCConnectorBaseURI = "/mobile/connector/PCS_TTC_05";

    service.get('/mobile/custom/TTCSalesOrderAPI_05/customer', function(req, res) {
        var result = [];
        result = customers;
        res.send(200, result);
    });

    service.get('/mobile/custom/TTCSalesOrderAPI_05/customer/:id', function(req, res) {
        var customerNumber = req.params.id;
        var result = {};

        var customerList = customers;
        console.log("Customers: " + JSON.stringify(customerList));
        var customerSelected = customerList.filter(function(customer) {
            return customer.customerNumber === customerNumber;
        });
        result = customerSelected[0];
        res.send(200, result);
    });

    service.post('/mobile/custom/TTCSalesOrderAPI_05/customer/:id/line', function(req, res) {
        var customerNumber = req.params.id;
        console.log("Request body: " + JSON.stringify(req.body));

        var customerList = customers;
        console.log("Customers before: " + JSON.stringify(customerList));
        var itemList = items;
        console.log("Items List: " + JSON.stringify(itemList));

        var itemObj = req.body;

        itemList.forEach(function(item) {
            if (item.Description === itemObj.itemDescription) {
                itemObj.itemNumber = item.Inventory_Item_ID + '';
                itemObj.lineNumber = 0;
            }
        });

        var lineArr = [];

        customerList.forEach(function(customer) {
            if (customer.customerNumber === customerNumber) {
                lineArr = customer["lines"];
                lineArr.push(itemObj);
                customer["lines"] = lineArr;
            }
        });

        console.log("Customers after: " + JSON.stringify(customerList));

        customers = customerList;

        res.send(200, "Line Added Successfully!");
    });

    service.get('/mobile/custom/TTCSalesOrderAPI_05/customer/:id/line', function(req, res) {
        var customerNumber = req.params.id;

        var customerList = customers;
        console.log("Customers: " + JSON.stringify(customerList));

        var lineArr = [];

        customerList.forEach(function(customer) {
            if (customer.customerNumber === customerNumber) {
                lineArr = customer["lines"];
            }
        });

        console.log("Lines: " + JSON.stringify(lineArr));
        res.send(200, lineArr);
    });

    service.get('/mobile/custom/TTCSalesOrderAPI_05/customer/:id/line/:lineid', function(req, res) {
        var customerNumber = req.params.id;
        var itemNumber = req.params.lineid;

        var customerList = customers;
        console.log("Customers: " + JSON.stringify(customerList));

        var lineArr = [];

        customerList.forEach(function(customer) {
            if (customer.customerNumber === customerNumber) {
                lineArr = customer["lines"];
            }
        });

        console.log("Lines: " + JSON.stringify(lineArr));

        var itemSelected = lineArr.filter(function(item) {
            return item.itemNumber === itemNumber;
        });
        result = itemSelected[0];

        res.send(200, result);
    });

    service.post('/mobile/custom/TTCSalesOrderAPI_05/customer/:id/submit', function(req, res) {
        var sdk = req.oracleMobile;
        var customerNumber = req.params.id;
        var result = {};

        var customerList = customers;
        var arrIndex;
        console.log("Customers: " + JSON.stringify(customerList));
        var customerSelected = customerList.filter(function(customer) {
            return customer.customerNumber === customerNumber;
        });
        result = customerSelected[0];

        console.log("Customer: " + JSON.stringify(result));

        var bodySpec = {
            "Header": null,
            "Body": {
                "start": {
                    "customerNumber": result.customerNumber,
                    "customerName": result.customerName,
                    "customerLastName": result.customerLastname,
                    "customerFirstName": result.customerFirstname,
                    "address1": result.address1,
                    "address2": result.address2,
                    "city": result.city,
                    "state": result.state,
                    "country": result.country,
                    "zip": result.zip,
                    "Lines": {
                        "lines": result.lines
                    },
                    "customerEmail": result.customerEmail,
                    "mcs_id": "User_05"
                }
            }
        };

        console.log("bodySpec = " + JSON.stringify(bodySpec));

        var handler = function(error, response, body) {
            if (error) {
                console.log("Create error: " + JSON.stringify(error));
                res.send(500, error.message);
            } else {
                console.log("Create success: " + JSON.stringify(body));
                customerList.forEach(function(customer, index) {
                    if (customer.customerNumber === customerNumber) {
                        arrIndex = index;
                        return;
                    }
                });
                customerList.splice(arrIndex, 1);
                customers = customerList;
                res.send(response.statusCode, body);
            }
        };

        var optionsList = {};
        optionsList.headers = { 'content-type': 'application/json' };
        optionsList.uri = PCSTTCConnectorBaseURI + '/start';
        optionsList.body = JSON.stringify(bodySpec);
        sdk.rest.post(optionsList, handler);
    });
};