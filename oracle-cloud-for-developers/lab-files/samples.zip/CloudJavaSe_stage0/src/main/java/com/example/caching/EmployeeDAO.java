/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
package com.example.caching;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.ws.rs.core.Response;

public class EmployeeDAO {

    private final CopyOnWriteArrayList<Employee> employeeList = EmployeeList.getInstance();
    private final static Logger LOGGER = Logger.getLogger(EmployeeDAO.class.getName());

    public Employee[] getAll() {
        LOGGER.log(Level.INFO, "EmployeeDao getAll method");
        return employeeList.toArray(new Employee[0]);
    }

    public Employee findById(long id) {
        LOGGER.log(Level.INFO, "EmployeeDao getById method");
        Optional<Employee> match
                = employeeList.stream()
                .filter(e -> e.getId() == id)
                .findFirst();
        if (match.isPresent()) {
            return match.get();
        } else {
            return null;
        }
    }

    public List<Employee> findByLastName(String lastName) {
        LOGGER.log(Level.INFO, "EmployeeDao findByLastName method");
        List<Employee> employees
                = employeeList.stream()
                .filter(e -> e.getLastName().equals(lastName))
                .collect(Collectors.toList());
        return employees;
    }

    public List<Employee> findByDepartment(String depatment) {
        LOGGER.log(Level.INFO, "EmployeeDao findByLastName method");
        List<Employee> employees
                = employeeList.stream()
                .filter(e -> e.getDept().equals(depatment))
                .collect(Collectors.toList());
        return employees;
    }

    public List<Employee> findByTitle(String title) {
        LOGGER.log(Level.INFO, "EmployeeDao findByTitle method");
        List<Employee> employees = employeeList.stream()
                .filter(e -> e.getTitle().equals(title)).collect(Collectors.toList());
        return employees;
    }

    public Response insert(Employee employee) {
        LOGGER.log(Level.INFO, "EmployeeDao insert method");
        employee.setId(++Employee.countId);
        employeeList.add(employee);
        return Response.status(201).build();
    }

    public boolean update(long id, Employee employee) {
        LOGGER.log(Level.INFO, "EmployeeDao update method");
        int matchIdx = 0;
        Optional<Employee> match = employeeList.stream()
                .filter(e -> e.getId() == id)
                .findFirst();
        if (match.isPresent()) {
            matchIdx = employeeList.indexOf(match.get());
            employeeList.set(matchIdx, employee);
            return true;
        } else {
            return false;
        }
    }

    public boolean delete(long id) {
        LOGGER.log(Level.INFO, "EmployeeDao delete method " + id);
        Predicate<Employee> employee = e -> e.getId() == id;
        if (!employeeList.removeIf(employee)) {
            LOGGER.log(Level.INFO,"Employee removed");
            return false;
        } else {
            return true;
        }
    }
}
