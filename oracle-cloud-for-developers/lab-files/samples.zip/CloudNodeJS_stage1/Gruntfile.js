/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
module.exports = function(grunt) {
    require('load-grunt-tasks')(grunt);

    // Project configuration.
    grunt.initConfig({
        compress: {
            main: {
                options: {
                    archive: 'employeeservice.zip',
                    pretty: true
                },
                expand: true,
                cwd: './',
                src: ['**/*'],
                dest: './'
            }
        }
    });
    // Default task(s).
    grunt.registerTask('default', ['compress']);
};