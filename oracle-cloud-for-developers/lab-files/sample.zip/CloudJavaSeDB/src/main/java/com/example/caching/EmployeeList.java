/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
package com.example.caching;

import java.util.concurrent.CopyOnWriteArrayList;


public class EmployeeList {
    private static final CopyOnWriteArrayList<Employee> employeeList = new CopyOnWriteArrayList<>();
    
    private EmployeeList(){
    }
    
    static{
        employeeList.add(new Employee("John","Smith","12-12-1980","Manager","Sales","john.smith@abc.com","923-814-0502"));
        employeeList.add(new Employee("Laura","Adams","02-11-1979","Manager","IT","laura.adams@abc.com","293-596-3547"));
        employeeList.add(new Employee("Peter","Williams","22-10-1966","Coordinator","HR","peter.williams@abc.com","923-814-0502"));
        employeeList.add(new Employee("Joana","Sanders","11-11-1976","Manager","Marketing","joana.sanders@abc.com","730-715-4446"));
        employeeList.add(new Employee("John","Drake","18-08-1988","Coordinator","Finance","john.drake@abc.com","769-569-1789"));
        employeeList.add(new Employee("Samuel","Williams","22-03-1985","Coordinator","Finance","samuel.williams@abc.com","429-071-2018"));
    }
    
    public static CopyOnWriteArrayList <Employee> getInstance(){
        return employeeList;
    }
}