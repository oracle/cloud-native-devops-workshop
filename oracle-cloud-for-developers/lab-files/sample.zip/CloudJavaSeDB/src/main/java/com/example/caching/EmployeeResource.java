/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
package com.example.caching;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/employees")
public class EmployeeResource {

  private final static Logger LOGGER = Logger.getLogger(EmployeeResource.class.getName());
  private final EmployeeDAO employeeDao = new EmployeeDAO();

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response getAllEmployees() {
    LOGGER.log(Level.INFO, "GET Method");
    return Response.ok(employeeDao.getAll()) //200
            .build();
  }

  @GET
  @Path("{id}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response getEmployee(@PathParam("id") long id) {
    LOGGER.log(Level.INFO, "GET Method by ID");
    Employee employee = employeeDao.findById(id);

    return Response.ok(employee) //200
            .build();
  }

  @GET
  @Path("{searchCriteria}/{searchValue}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response searchEmployees(@PathParam("searchCriteria") String searchCriteria, @PathParam("searchValue") String searchValue) throws Exception {
    List<Employee> employees = null;
    if (searchCriteria.equals("title")) {
      employees = employeeDao.findByTitle(searchValue);
    } else if (searchCriteria.equals("lastname")) {
      employees = employeeDao.findByLastName(searchValue);
    } else if (searchCriteria.equals("department")) {
      employees = employeeDao.findByDepartment(searchValue);
    } else {
      throw new Exception("Filter criteria not valid");
    }

    return Response.ok() //200
            .entity(employees.toArray(new Employee[0]))
            .build();
  }

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public Response addEmployee(Employee employee) {
    LOGGER.log(Level.INFO, "POST Method");
    employeeDao.insert(employee);
    return Response.status(201)
            .build();
  }

  @PUT
  @Path("{id}")
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  public Response updateEmployee(@PathParam("id") long id, Employee employee) {
    LOGGER.log(Level.INFO, "PUT Method {0}", id);
    boolean response = employeeDao.update(id, employee);
    if (response) {
      return Response.status(Response.Status.OK)
              .build();
    } else {
      return Response.status(Response.Status.NOT_FOUND).build();
    }
  }

  @DELETE
  @Path("{id}")
  public void deleteEmployee(@PathParam("id") long id) {
    LOGGER.log(Level.INFO, "DELETE Method {0}", id);
    boolean response = employeeDao.delete(id);
    if (!response) {
      throw new NotFoundException("Error Employee " + id + " not found");
    } else {
      Response.status(Response.Status.OK)
              .build();
    }
  }

  @GET
  @Path("{id}/portrait")
  public Response getEmployeePortrait(@PathParam("id") long id) {
    LOGGER.log(Level.INFO, "GET Method by ID");
    File file = new File("portraits/" + id + ".png");
    if (file.exists()) {
      return Response.ok(file, "image/png") //200
              .build();
    } else {
      return Response.ok(getClass().getResourceAsStream("nopic.png"), "image/png") //200
              .build();
    }
  }
}
