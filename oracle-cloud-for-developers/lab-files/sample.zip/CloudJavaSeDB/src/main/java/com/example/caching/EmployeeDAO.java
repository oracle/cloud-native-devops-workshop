/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
package com.example.caching;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Response;

public class EmployeeDAO {

  private final static Logger LOGGER = Logger.getLogger(EmployeeDAO.class.getName());

  private final Connection conn;

  public EmployeeDAO() {
    conn = DBConnection.getInstance().getConnection();
  }

  public Employee[] getAll() {
    String sql = "SELECT * FROM EMPLOYEE";
    try (PreparedStatement st = this.conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery()) {
      List<Employee> employees = new ArrayList<>();
      while (rs.next()) {
        employees.add(buildEmployee(rs));
      }
      return employees.toArray(new Employee[0]);
    } catch (SQLException ex) {
      LOGGER.log(Level.WARNING, "ERR", ex);
      throw new RuntimeException(ex);
    }
  }

  public Employee findById(long id) {
    LOGGER.log(Level.INFO, "EmployeeDao getById method");
    String sql = "SELECT * FROM EMPLOYEE WHERE ID = " + id;
    try (PreparedStatement st = this.conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery()) {
      rs.next();
      return buildEmployee(rs);
    } catch (SQLException ex) {
      LOGGER.log(Level.WARNING, "ERR", ex);
      throw new RuntimeException(ex);
    }
  }

  public List<Employee> findByLastName(String lastName) {
    LOGGER.log(Level.INFO, "EmployeeDao findByLastName method");
    String sql = "SELECT * FROM EMPLOYEE WHERE LASTNAME LIKE ?";
    return findBy(sql, lastName);
  }

  public List<Employee> findByDepartment(String depatment) {
    LOGGER.log(Level.INFO, "EmployeeDao findByLastName method");
    String sql = "SELECT * FROM EMPLOYEE WHERE DEPT LIKE ?";
    return findBy(sql, depatment);
  }

  public List<Employee> findByTitle(String title) {
    LOGGER.log(Level.INFO, "EmployeeDao findByTitle method");
    String sql = "SELECT * FROM EMPLOYEE WHERE LASTNAME LIKE ?";
    return findBy(sql, title);
  }

  public Response insert(Employee employee) {
    LOGGER.log(Level.INFO, "EmployeeDao insert method");
    String sql = "INSERT INTO EMPLOYEE(ID,FIRSTNAME,LASTNAME,EMAIL,PHONE,BIRTHDAY,TITLE,DEPT) VALUES (EMPLOYEE_SEQ.NEXTVAL, ?,?,?,?,?,?,?)";
    try (PreparedStatement st = this.conn.prepareStatement(sql)) {
      st.setString(1, employee.getFirstName());
      st.setString(2, employee.getLastName());
      st.setString(3, employee.getEmail());
      st.setString(4, employee.getPhone());
      st.setString(5, employee.getBirthDate());
      st.setString(6, employee.getTitle());
      st.setString(7, employee.getDept());
      st.execute();
      
      return Response.status(201).build();
    } catch (SQLException ex) {
      LOGGER.log(Level.WARNING, "ERR", ex);
      throw new RuntimeException(ex);
    }
  }

  public boolean update(long id, Employee employee) {
    LOGGER.log(Level.INFO, "EmployeeDao update method");
    String sql = "UPDATE EMPLOYEE SET FIRSTNAME=?, LASTNAME=?, EMAIL=?, PHONE=?, BIRTHDAY=?, TITLE=?, DEPT=? WHERE ID = ?";
    try (PreparedStatement st = this.conn.prepareStatement(sql)) {
      st.setString(1, employee.getFirstName());
      st.setString(2, employee.getLastName());
      st.setString(3, employee.getEmail());
      st.setString(4, employee.getPhone());
      st.setString(5, employee.getBirthDate());
      st.setString(6, employee.getTitle());
      st.setString(7, employee.getDept());
      st.setLong(8, id);
      st.execute();
      
      return true;
    } catch (SQLException ex) {
      LOGGER.log(Level.WARNING, "ERR", ex);
      return false;
    }
  }

  public boolean delete(long id) {
    LOGGER.log(Level.INFO, "EmployeeDao delete method " + id);
    String sql = "DELETE FROM EMPLOYEE WHERE ID = ?";
    try (PreparedStatement st = this.conn.prepareStatement(sql)) {
      st.setLong(1, id);
      st.execute();
      
      return true;
    } catch (SQLException ex) {
      return false;
    }
  }

  private List<Employee> findBy(String sql, String value) throws RuntimeException {
    try (PreparedStatement st = this.conn.prepareStatement(sql)) {
      st.setString(1, value);
      try (ResultSet rs = st.executeQuery()) {
        List<Employee> employees = new ArrayList<>();
        while (rs.next()) {
          employees.add(buildEmployee(rs));
        }
        return employees;
      }
    } catch (SQLException ex) {
      LOGGER.log(Level.WARNING, "ERR", ex);
      throw new RuntimeException(ex);
    }
  }

  private Employee buildEmployee(ResultSet rs) throws SQLException {
    Employee e = new Employee();
    e.setBirthDate(rs.getString("BIRTHDAY"));
    e.setDept(rs.getString("DEPT"));
    e.setEmail(rs.getString("EMAIL"));
    e.setFirstName(rs.getString("FIRSTNAME"));
    e.setId(rs.getLong("ID"));
    e.setLastName(rs.getString("LASTNAME"));
    e.setPhone(rs.getString("PHONE"));
    e.setTitle(rs.getString("TITLE"));
    return e;
  }
}
