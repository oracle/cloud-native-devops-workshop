/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
package com.example.caching;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Employee {

    private long id;
    private String firstName;
    private String lastName;
    private String birthDate;
    private String title;
    private String dept;
    private String email;
    private String phone;

    public static int countId = 0;
    
    public Employee() {
    }   

    public Employee(String firstName, String lastName, String birthDate,
            String title, String dept, String email, String phone) {
        countId++;
        this.id = countId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.title = title;
        this.dept = dept;
        this.email = email;
        this.phone = phone;
    }

    public Employee(long id, String firstName, String lastName, String birthDate,
            String title, String dept, String email, String phone) {
        this(firstName, lastName, birthDate, title, dept, email, phone);
        this.id = id;
    }

    @JsonProperty
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @JsonProperty
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty
    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    @JsonProperty
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty
    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    @JsonProperty
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
