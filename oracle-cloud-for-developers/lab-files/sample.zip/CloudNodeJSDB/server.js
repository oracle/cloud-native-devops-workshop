/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
var express = require('express');
var fileUpload = require('express-fileupload');
var app = express();
var bodyParser = require('body-parser');
var _ = require('lodash')

//FileSystem
var fs = require("fs");

var oracledb = require('oracledb');
oracledb.autoCommit = true;

var connectionProperties = {
    user: process.env.DBAAS_USER_NAME || "oracle",
    password: process.env.DBAAS_USER_PASSWORD || "oracle",
    connectString: process.env.DBAAS_DEFAULT_CONNECT_DESCRIPTOR || "127.0.0.1:1521/xe"
};

function doRelease(connection) {
    connection.release(function (err) {
        if (err) {
            console.error(err.message);
        }
    });
}

// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({ type: '*/*' }));

var PORT = process.env.PORT || 8089;

var router = express.Router();

router.use(function (request, response, next) {
    console.log("REQUEST:" + request.method + "   " + request.url);
    console.log("BODY:" + JSON.stringify(request.body));
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT, OPTIONS');
    response.setHeader('Access-Control-Allow-Headers', 'origin, content-type, accept, authorization');
    response.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

//Return list of all employees
router.route('/employees').get(function (request, response) {
    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("SELECT ID, FIRSTNAME, LASTNAME, EMAIL, PHONE, BIRTHDAY, TITLE, DEPT FROM EMPLOYEE", [], { outFormat: oracledb.OBJECT },
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                console.log("RESULTSET:" + JSON.stringify(result));
                var employees = [];
                result.rows.forEach(function (element) {
                    employees.push({
                        id: element.ID,
                        firstName: element.FIRSTNAME,
                        lastName: element.LASTNAME,
                        email: element.EMAIL,
                        phone: element.PHONE,
                        birthDate: element.BIRTHDATE,
                        title: element.TITLE,
                        dept: element.DEPT

                    });
                }, this);
                response.json(employees);
                doRelease(connection);
            });
    });
});
//Return employee with that ID
router.route('/employees/:employeeId').get(function (request, response) {
    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("SELECT ID, FIRSTNAME, LASTNAME, EMAIL, PHONE, BIRTHDAY, TITLE, DEPT FROM EMPLOYEE WHERE ID=:ID", [body.id], { outFormat: oracledb.OBJECT },
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                console.log("RESULTSET:" + JSON.stringify(result));
                var employees = [];
                result.rows.forEach(function (element) {
                    employees.push({
                        id: element.ID,
                        firstName: element.FIRSTNAME,
                        lastName: element.LASTNAME,
                        email: element.EMAIL,
                        phone: element.PHONE,
                        birthDate: element.BIRTHDAY,
                        title: element.TITLE,
                        dept: element.DEPT

                    });
                }, this);
                response.json(employees[0]);
                doRelease(connection);
            });
    });
});

//Search by name
router.route('/employees/lastname/:query').get(function (request, response) {
    var query = request.params.query;
    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("SELECT ID, FIRSTNAME, LASTNAME, EMAIL, PHONE, BIRTHDAY, TITLE, DEPT FROM EMPLOYEE WHERE LASTNAME = '" + query + "'", [], { outFormat: oracledb.OBJECT },
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                console.log("RESULTSET:" + JSON.stringify(result));
                var employees = [];
                result.rows.forEach(function (element) {
                    employees.push({
                        id: element.ID,
                        firstName: element.FIRSTNAME,
                        lastName: element.LASTNAME,
                        email: element.EMAIL,
                        phone: element.PHONE,
                        birthDate: element.BIRTHDAY,
                        title: element.TITLE,
                        dept: element.DEPT

                    });
                }, this);
                response.json(employees);
                doRelease(connection);
            });
    });
});
//Search by title
router.route('/employees/title/:query').get(function (request, response) {
    var query = request.params.query;
    var query = request.params.query;
    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("SELECT ID, FIRSTNAME, LASTNAME, EMAIL, PHONE, BIRTHDAY, TITLE, DEPT FROM EMPLOYEE WHERE TITLE = '" + query + "'", [], { outFormat: oracledb.OBJECT },
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                console.log("RESULTSET:" + JSON.stringify(result));
                var employees = [];
                result.rows.forEach(function (element) {
                    employees.push({
                        id: element.ID,
                        firstName: element.FIRSTNAME,
                        lastName: element.LASTNAME,
                        email: element.EMAIL,
                        phone: element.PHONE,
                        birthDate: element.BIRTHDAY,
                        title: element.TITLE,
                        dept: element.DEPT

                    });
                }, this);
                response.json(employees);
                doRelease(connection);
            });
    });


});
//Search by department
router.route('/employees/department/:query').get(function (request, response) {
    var query = request.params.query;
    var query = request.params.query;
    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("SELECT ID, FIRSTNAME, LASTNAME, EMAIL, PHONE, BIRTHDAY, TITLE, DEPT FROM EMPLOYEE WHERE DEPT = '" + query + "'", [], { outFormat: oracledb.OBJECT },
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                console.log("RESULTSET:" + JSON.stringify(result));
                var employees = [];
                result.rows.forEach(function (element) {
                    employees.push({
                        id: element.ID,
                        firstName: element.FIRSTNAME,
                        lastName: element.LASTNAME,
                        email: element.EMAIL,
                        phone: element.PHONE,
                        birthDate: element.BIRTHDAY,
                        title: element.TITLE,
                        dept: element.DEPT

                    });
                }, this);
                response.json(employees);
                doRelease(connection);
            });
    });
});
//Add an employee
router.route('/employees').post(function (request, response) {
    var body = request.body;
    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("INSERT INTO EMPLOYEE(ID, FIRSTNAME, LASTNAME, EMAIL, PHONE, BIRTHDAY, TITLE, DEPT) VALUES(EMPLOYEE_SEQ.NEXTVAL, :FIRSTNAME, :LASTNAME, :EMAIL, :PHONE, :BIRTHDAY, :TITLE, :DEPT)", [body.firstName, body.lastName, body.email, body.phone, body.birthDate, body.title, body.dept],
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                response.end();
                doRelease(connection);
            });
    });
});
//Update an employee
router.route('/employees/:employeeId').put(function (request, response) {
    var body = request.body;
    body.id = request.params.employeeId;

    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("UPDATE EMPLOYEE SET FIRSTNAME=:FIRSTNAME, LASTNAME=:LASTNAME, EMAIL=:EMAIL, PHONE=:PHONE, BIRTHDAY=:BIRTHDAY, TITLE=:TITLE, DEPT=:DEPT WHERE ID=:ID", [body.firstName, body.lastName, body.email, body.phone, body.birthDate, body.title, body.dept, body.id],
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                response.end();
                doRelease(connection);
            });
    });
});
//Delete an employee
router.route('/employees/:employeeId').delete(function (request, response) {
    var employeeId = request.params.employeeId;
    oracledb.getConnection(connectionProperties, function (err, connection) {
        if (err) {
            console.error(err.message);
            response.status(500).send("Error connecting to DB ::" + JSON.stringify(connectionProperties) + "::" + err.message);
            return;
        }
        connection.execute("DELETE FROM EMPLOYEE WHERE ID=:ID", [employeeId],
            function (err, result) {
                if (err) {
                    console.error(err.message);
                    response.status(500).send("Error getting data from DB " + err.message);
                    doRelease(connection);
                    return;
                }
                response.end();
                doRelease(connection);
            });
    });
});

//return employee portrait
router.route('/employees/:employeeId/portrait').get(function (request, response) {
    var filename = "portraits/" + request.params.employeeId + ".png";
    try {
        fs.accessSync(filename, fs.F_OK);
        response.setHeader('Content-type', 'image/png');
        var filestream = fs.createReadStream(filename);
        filestream.pipe(response);
    } catch (e) {
        response.setHeader('Content-type', 'image/png');
        var filestream = fs.createReadStream("nopic.png");
        filestream.pipe(response);
    }
});

//Put employee portrait
router.route('/employees/:employeeId/portrait').put(fileUpload(), function (request, response) {
    var filename = "portraits/" + request.params.employeeId + ".png";
    if (!request.files) {
        response.sendStatus(400); // bad request

    } else {
        var file = request.files.portrait;
        file.mv(filename, function (err) {
            if (err) {
                response.sendStatus(500);
            } else {
                response.sendStatus(204); //No content
            }
        });
    }
});

app.use('/', router);
app.listen(PORT);

console.log("Server started in port:" + PORT);