To install grunt globally:
npm install -g grunt-cli
To add grunt to a project:
npm install grunt --save-dev
npm install load-grunt-tasks --save-dev
npm install grunt-contrib-compress --save-dev
To compile and package the project:
npm install
grunt
