/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */
var express = require('express');
var fileUpload = require('express-fileupload');
var app = express();
var bodyParser = require('body-parser');
var _ = require('lodash')

//FileSystem
var fs = require("fs");

var data = require('./employee-40.json');
var currentId = 999;


var PORT = 8089;

var router = express.Router();

//Return list of all employees
router.route('/employees').get(function(request, response) { response.json(data) });
//Return employee with that ID
router.route('/employees/:employeeId').get(function(request, response) {
    var employees = _.find(data, function(employee) {
        return employee.id == request.params.employeeId;
    })
    if (_.isEmpty(employees)) {
        response.end();
    } else {
        response.json(employees);
    }
});

//Search by name
router.route('/employees/lastname/:query').get(function(request, response) {
    var employees = _.filter(data, function(employee) {
        return employee.lastName.indexOf(request.params.query) > -1;
    });
    if (_.isEmpty(employees)) {
        response.end();
    } else {
        response.json(employees);
    }

});
//Search by title
router.route('/employees/title/:query').get(function(request, response) {
    var employees = _.filter(data, function(employee) {
        return employee.title.indexOf(request.params.query) > -1;
    });
    if (_.isEmpty(employees)) {
        response.end();
    } else {
        response.json(employees);
    }

});
//Search by department
router.route('/employees/department/:query').get(function(request, response) {
    var employees = _.find(data, function(employee) {
        return employee.department.indexOf(request.params.query) > -1;
    });
    if (_.isEmpty(employees)) {
        response.end();
    } else {
        response.json(employees);
    }

});
//Add an employee
router.route('/employees').post(bodyParser.json(), function(request, response) {
    var body = request.body;
    body.id = currentId++;
    data.push(body);
    response.set('Content-Type', 'text/plain');
    response.send(body.id);
    response.end();
});
//Update an employee
router.route('/employees/:employeeId').put(bodyParser.json(), function(request, response) {
    var index = _.findIndex(data, function(employee) {
        return employee.id == request.params.employeeId;
    });
    var body = request.body;
    body.id = data[index].id;
    data.splice(index, 1, body);
    response.end();
});
//Delete an employee
router.route('/employees/:employeeId').delete(function(request, response) {
    _.remove(data, function(employee) {
        return employee.id == request.params.employeeId;
    });
    response.end();
});


//return employee portrait
router.route('/employees/:employeeId/portrait').get(function(request, response) {
    var filename = "portraits/" + request.params.employeeId + ".png";
    try {
        fs.accessSync(filename, fs.F_OK);
        response.setHeader('Content-type', 'image/png');
        var filestream = fs.createReadStream(filename);
        filestream.pipe(response);
    } catch (e) {
        response.setHeader('Content-type', 'image/png');
        var filestream = fs.createReadStream("nopic.png");
        filestream.pipe(response);
    }
});

//return employee portrait
router.route('/employees/:employeeId/portrait').put(fileUpload(), function(request, response) {
    var filename = "portraits/" + request.params.employeeId + ".png";
    if (!request.files) {
        response.sendStatus(400); // bad request

    } else {
        var file = request.files.portrait;
        file.mv(filename, function(err) {
            if (err) {
                response.sendStatus(500);
            } else {
                response.sendStatus(204); //No content
            }
        });
    }
});



app.use('/', router);
app.listen(PORT);

console.log("Server started in port:" + PORT);